﻿namespace SlotMachine
{
    partial class frmSlotMachine
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmSlotMachine));
            this.lblWindowCounter1 = new System.Windows.Forms.Label();
            this.tmrWindowCounter1 = new System.Windows.Forms.Timer(this.components);
            this.pbxWindow2 = new System.Windows.Forms.PictureBox();
            this.pbxPicture0 = new System.Windows.Forms.PictureBox();
            this.pbxPicture1 = new System.Windows.Forms.PictureBox();
            this.pbxPicture2 = new System.Windows.Forms.PictureBox();
            this.pbxPicture3 = new System.Windows.Forms.PictureBox();
            this.pbxPicture4 = new System.Windows.Forms.PictureBox();
            this.pbxPicture5 = new System.Windows.Forms.PictureBox();
            this.pbxPicture6 = new System.Windows.Forms.PictureBox();
            this.tmrWindowCounter2 = new System.Windows.Forms.Timer(this.components);
            this.pbxWindow1 = new System.Windows.Forms.PictureBox();
            this.lblWindowCounter2 = new System.Windows.Forms.Label();
            this.tmrWindowCounter3 = new System.Windows.Forms.Timer(this.components);
            this.pbxWindow3 = new System.Windows.Forms.PictureBox();
            this.lblWindowCounter3 = new System.Windows.Forms.Label();
            this.btnLever = new System.Windows.Forms.Button();
            this.pbxFlashLight1 = new System.Windows.Forms.PictureBox();
            this.pbxFlashLight2 = new System.Windows.Forms.PictureBox();
            this.pbxFlashLight3 = new System.Windows.Forms.PictureBox();
            this.tmrFlashLight = new System.Windows.Forms.Timer(this.components);
            this.lblCashLabel = new System.Windows.Forms.Label();
            this.lblCash = new System.Windows.Forms.Label();
            this.lblBetLabel = new System.Windows.Forms.Label();
            this.lblBet = new System.Windows.Forms.Label();
            this.btnReset = new System.Windows.Forms.Button();
            this.btnBetMore = new System.Windows.Forms.Button();
            this.btnBetLess = new System.Windows.Forms.Button();
            this.btnBetAll = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pbxWindow2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxPicture0)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxPicture1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxPicture2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxPicture3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxPicture4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxPicture5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxPicture6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxWindow1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxWindow3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxFlashLight1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxFlashLight2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxFlashLight3)).BeginInit();
            this.SuspendLayout();
            // 
            // lblWindowCounter1
            // 
            this.lblWindowCounter1.AutoSize = true;
            this.lblWindowCounter1.Location = new System.Drawing.Point(92, 66);
            this.lblWindowCounter1.Name = "lblWindowCounter1";
            this.lblWindowCounter1.Size = new System.Drawing.Size(13, 13);
            this.lblWindowCounter1.TabIndex = 0;
            this.lblWindowCounter1.Text = "0";
            this.lblWindowCounter1.Visible = false;
            // 
            // tmrWindowCounter1
            // 
            this.tmrWindowCounter1.Tick += new System.EventHandler(this.tmrWindowCounter1_Tick);
            // 
            // pbxWindow2
            // 
            this.pbxWindow2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pbxWindow2.Location = new System.Drawing.Point(313, 129);
            this.pbxWindow2.Name = "pbxWindow2";
            this.pbxWindow2.Size = new System.Drawing.Size(100, 50);
            this.pbxWindow2.TabIndex = 1;
            this.pbxWindow2.TabStop = false;
            // 
            // pbxPicture0
            // 
            this.pbxPicture0.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbxPicture0.BackgroundImage")));
            this.pbxPicture0.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pbxPicture0.Location = new System.Drawing.Point(854, 185);
            this.pbxPicture0.Name = "pbxPicture0";
            this.pbxPicture0.Size = new System.Drawing.Size(100, 67);
            this.pbxPicture0.TabIndex = 2;
            this.pbxPicture0.TabStop = false;
            // 
            // pbxPicture1
            // 
            this.pbxPicture1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbxPicture1.BackgroundImage")));
            this.pbxPicture1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pbxPicture1.Location = new System.Drawing.Point(854, 290);
            this.pbxPicture1.Name = "pbxPicture1";
            this.pbxPicture1.Size = new System.Drawing.Size(100, 66);
            this.pbxPicture1.TabIndex = 3;
            this.pbxPicture1.TabStop = false;
            // 
            // pbxPicture2
            // 
            this.pbxPicture2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbxPicture2.BackgroundImage")));
            this.pbxPicture2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pbxPicture2.Location = new System.Drawing.Point(854, 372);
            this.pbxPicture2.Name = "pbxPicture2";
            this.pbxPicture2.Size = new System.Drawing.Size(100, 74);
            this.pbxPicture2.TabIndex = 4;
            this.pbxPicture2.TabStop = false;
            // 
            // pbxPicture3
            // 
            this.pbxPicture3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbxPicture3.BackgroundImage")));
            this.pbxPicture3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pbxPicture3.Location = new System.Drawing.Point(983, 185);
            this.pbxPicture3.Name = "pbxPicture3";
            this.pbxPicture3.Size = new System.Drawing.Size(100, 74);
            this.pbxPicture3.TabIndex = 5;
            this.pbxPicture3.TabStop = false;
            // 
            // pbxPicture4
            // 
            this.pbxPicture4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbxPicture4.BackgroundImage")));
            this.pbxPicture4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pbxPicture4.Location = new System.Drawing.Point(983, 290);
            this.pbxPicture4.Name = "pbxPicture4";
            this.pbxPicture4.Size = new System.Drawing.Size(100, 66);
            this.pbxPicture4.TabIndex = 6;
            this.pbxPicture4.TabStop = false;
            // 
            // pbxPicture5
            // 
            this.pbxPicture5.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbxPicture5.BackgroundImage")));
            this.pbxPicture5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pbxPicture5.Location = new System.Drawing.Point(983, 372);
            this.pbxPicture5.Name = "pbxPicture5";
            this.pbxPicture5.Size = new System.Drawing.Size(100, 74);
            this.pbxPicture5.TabIndex = 7;
            this.pbxPicture5.TabStop = false;
            // 
            // pbxPicture6
            // 
            this.pbxPicture6.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbxPicture6.BackgroundImage")));
            this.pbxPicture6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pbxPicture6.Location = new System.Drawing.Point(983, 466);
            this.pbxPicture6.Name = "pbxPicture6";
            this.pbxPicture6.Size = new System.Drawing.Size(100, 74);
            this.pbxPicture6.TabIndex = 8;
            this.pbxPicture6.TabStop = false;
            // 
            // tmrWindowCounter2
            // 
            this.tmrWindowCounter2.Interval = 90;
            this.tmrWindowCounter2.Tick += new System.EventHandler(this.tmrWindowCounter2_Tick);
            // 
            // pbxWindow1
            // 
            this.pbxWindow1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pbxWindow1.Location = new System.Drawing.Point(60, 129);
            this.pbxWindow1.Name = "pbxWindow1";
            this.pbxWindow1.Size = new System.Drawing.Size(100, 50);
            this.pbxWindow1.TabIndex = 10;
            this.pbxWindow1.TabStop = false;
            // 
            // lblWindowCounter2
            // 
            this.lblWindowCounter2.AutoSize = true;
            this.lblWindowCounter2.Location = new System.Drawing.Point(346, 66);
            this.lblWindowCounter2.Name = "lblWindowCounter2";
            this.lblWindowCounter2.Size = new System.Drawing.Size(13, 13);
            this.lblWindowCounter2.TabIndex = 9;
            this.lblWindowCounter2.Text = "0";
            this.lblWindowCounter2.Visible = false;
            // 
            // tmrWindowCounter3
            // 
            this.tmrWindowCounter3.Tick += new System.EventHandler(this.tmrWindowCounter3_Tick);
            // 
            // pbxWindow3
            // 
            this.pbxWindow3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pbxWindow3.Location = new System.Drawing.Point(557, 129);
            this.pbxWindow3.Name = "pbxWindow3";
            this.pbxWindow3.Size = new System.Drawing.Size(98, 50);
            this.pbxWindow3.TabIndex = 12;
            this.pbxWindow3.TabStop = false;
            // 
            // lblWindowCounter3
            // 
            this.lblWindowCounter3.AutoSize = true;
            this.lblWindowCounter3.Location = new System.Drawing.Point(601, 66);
            this.lblWindowCounter3.Name = "lblWindowCounter3";
            this.lblWindowCounter3.Size = new System.Drawing.Size(13, 13);
            this.lblWindowCounter3.TabIndex = 11;
            this.lblWindowCounter3.Text = "0";
            this.lblWindowCounter3.Visible = false;
            // 
            // btnLever
            // 
            this.btnLever.Location = new System.Drawing.Point(300, 256);
            this.btnLever.Name = "btnLever";
            this.btnLever.Size = new System.Drawing.Size(113, 86);
            this.btnLever.TabIndex = 13;
            this.btnLever.Text = "Start";
            this.btnLever.UseVisualStyleBackColor = true;
            this.btnLever.Click += new System.EventHandler(this.btnLever_Click);
            // 
            // pbxFlashLight1
            // 
            this.pbxFlashLight1.Location = new System.Drawing.Point(27, 82);
            this.pbxFlashLight1.Name = "pbxFlashLight1";
            this.pbxFlashLight1.Size = new System.Drawing.Size(179, 138);
            this.pbxFlashLight1.TabIndex = 14;
            this.pbxFlashLight1.TabStop = false;
            // 
            // pbxFlashLight2
            // 
            this.pbxFlashLight2.Location = new System.Drawing.Point(279, 82);
            this.pbxFlashLight2.Name = "pbxFlashLight2";
            this.pbxFlashLight2.Size = new System.Drawing.Size(171, 138);
            this.pbxFlashLight2.TabIndex = 15;
            this.pbxFlashLight2.TabStop = false;
            // 
            // pbxFlashLight3
            // 
            this.pbxFlashLight3.Location = new System.Drawing.Point(522, 82);
            this.pbxFlashLight3.Name = "pbxFlashLight3";
            this.pbxFlashLight3.Size = new System.Drawing.Size(170, 138);
            this.pbxFlashLight3.TabIndex = 16;
            this.pbxFlashLight3.TabStop = false;
            // 
            // tmrFlashLight
            // 
            this.tmrFlashLight.Tick += new System.EventHandler(this.tmrFlashLight_Tick);
            // 
            // lblCashLabel
            // 
            this.lblCashLabel.AutoSize = true;
            this.lblCashLabel.Location = new System.Drawing.Point(56, 24);
            this.lblCashLabel.Name = "lblCashLabel";
            this.lblCashLabel.Size = new System.Drawing.Size(31, 13);
            this.lblCashLabel.TabIndex = 17;
            this.lblCashLabel.Text = "Cash";
            // 
            // lblCash
            // 
            this.lblCash.AutoSize = true;
            this.lblCash.Location = new System.Drawing.Point(119, 24);
            this.lblCash.Name = "lblCash";
            this.lblCash.Size = new System.Drawing.Size(13, 13);
            this.lblCash.TabIndex = 18;
            this.lblCash.Text = "0";
            // 
            // lblBetLabel
            // 
            this.lblBetLabel.AutoSize = true;
            this.lblBetLabel.Location = new System.Drawing.Point(56, 41);
            this.lblBetLabel.Name = "lblBetLabel";
            this.lblBetLabel.Size = new System.Drawing.Size(23, 13);
            this.lblBetLabel.TabIndex = 19;
            this.lblBetLabel.Text = "Bet";
            // 
            // lblBet
            // 
            this.lblBet.AutoSize = true;
            this.lblBet.Location = new System.Drawing.Point(119, 41);
            this.lblBet.Name = "lblBet";
            this.lblBet.Size = new System.Drawing.Size(13, 13);
            this.lblBet.TabIndex = 20;
            this.lblBet.Text = "0";
            // 
            // btnReset
            // 
            this.btnReset.Location = new System.Drawing.Point(27, 397);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new System.Drawing.Size(75, 23);
            this.btnReset.TabIndex = 21;
            this.btnReset.Text = "Reset";
            this.btnReset.UseVisualStyleBackColor = true;
            this.btnReset.Click += new System.EventHandler(this.btnReset_Click);
            // 
            // btnBetMore
            // 
            this.btnBetMore.Location = new System.Drawing.Point(207, 277);
            this.btnBetMore.Name = "btnBetMore";
            this.btnBetMore.Size = new System.Drawing.Size(61, 65);
            this.btnBetMore.TabIndex = 22;
            this.btnBetMore.Text = "Increase Bet";
            this.btnBetMore.UseVisualStyleBackColor = true;
            this.btnBetMore.Click += new System.EventHandler(this.btnBetMore_Click);
            // 
            // btnBetLess
            // 
            this.btnBetLess.Location = new System.Drawing.Point(446, 277);
            this.btnBetLess.Name = "btnBetLess";
            this.btnBetLess.Size = new System.Drawing.Size(68, 65);
            this.btnBetLess.TabIndex = 23;
            this.btnBetLess.Text = "Decrease Bet";
            this.btnBetLess.UseVisualStyleBackColor = true;
            this.btnBetLess.Click += new System.EventHandler(this.btnBetLess_Click);
            // 
            // btnBetAll
            // 
            this.btnBetAll.Location = new System.Drawing.Point(279, 370);
            this.btnBetAll.Name = "btnBetAll";
            this.btnBetAll.Size = new System.Drawing.Size(152, 33);
            this.btnBetAll.TabIndex = 24;
            this.btnBetAll.Text = "Bet It All!";
            this.btnBetAll.UseVisualStyleBackColor = true;
            this.btnBetAll.Click += new System.EventHandler(this.btnBetAll_Click);
            // 
            // frmSlotMachine
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(732, 432);
            this.Controls.Add(this.btnBetAll);
            this.Controls.Add(this.btnBetLess);
            this.Controls.Add(this.btnBetMore);
            this.Controls.Add(this.btnReset);
            this.Controls.Add(this.lblBet);
            this.Controls.Add(this.lblBetLabel);
            this.Controls.Add(this.lblCash);
            this.Controls.Add(this.lblCashLabel);
            this.Controls.Add(this.btnLever);
            this.Controls.Add(this.pbxWindow3);
            this.Controls.Add(this.lblWindowCounter3);
            this.Controls.Add(this.pbxWindow1);
            this.Controls.Add(this.lblWindowCounter2);
            this.Controls.Add(this.pbxPicture6);
            this.Controls.Add(this.pbxPicture5);
            this.Controls.Add(this.pbxPicture4);
            this.Controls.Add(this.pbxPicture3);
            this.Controls.Add(this.pbxPicture2);
            this.Controls.Add(this.pbxPicture1);
            this.Controls.Add(this.pbxPicture0);
            this.Controls.Add(this.pbxWindow2);
            this.Controls.Add(this.lblWindowCounter1);
            this.Controls.Add(this.pbxFlashLight3);
            this.Controls.Add(this.pbxFlashLight2);
            this.Controls.Add(this.pbxFlashLight1);
            this.Name = "frmSlotMachine";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.pbxWindow2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxPicture0)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxPicture1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxPicture2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxPicture3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxPicture4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxPicture5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxPicture6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxWindow1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxWindow3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxFlashLight1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxFlashLight2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxFlashLight3)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblWindowCounter1;
        private System.Windows.Forms.Timer tmrWindowCounter1;
        private System.Windows.Forms.PictureBox pbxWindow2;
        private System.Windows.Forms.PictureBox pbxPicture0;
        private System.Windows.Forms.PictureBox pbxPicture1;
        private System.Windows.Forms.PictureBox pbxPicture2;
        private System.Windows.Forms.PictureBox pbxPicture3;
        private System.Windows.Forms.PictureBox pbxPicture4;
        private System.Windows.Forms.PictureBox pbxPicture5;
        private System.Windows.Forms.PictureBox pbxPicture6;
        private System.Windows.Forms.Timer tmrWindowCounter2;
        private System.Windows.Forms.PictureBox pbxWindow1;
        private System.Windows.Forms.Label lblWindowCounter2;
        private System.Windows.Forms.Timer tmrWindowCounter3;
        private System.Windows.Forms.PictureBox pbxWindow3;
        private System.Windows.Forms.Label lblWindowCounter3;
        private System.Windows.Forms.Button btnLever;
        private System.Windows.Forms.PictureBox pbxFlashLight1;
        private System.Windows.Forms.PictureBox pbxFlashLight2;
        private System.Windows.Forms.PictureBox pbxFlashLight3;
        private System.Windows.Forms.Timer tmrFlashLight;
        private System.Windows.Forms.Label lblCashLabel;
        private System.Windows.Forms.Label lblCash;
        private System.Windows.Forms.Label lblBetLabel;
        private System.Windows.Forms.Label lblBet;
        private System.Windows.Forms.Button btnReset;
        private System.Windows.Forms.Button btnBetMore;
        private System.Windows.Forms.Button btnBetLess;
        private System.Windows.Forms.Button btnBetAll;
    }
}

