﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SlotMachine
{
    public partial class frmSlotMachine : Form
    {
        //fields
        private bool myblnFlash1 = false;
        private bool myblnFlash2 = false;
        private bool myblnFlash3 = false;
        private decimal mydecCurrentCash = 0;
        private decimal mydecBet = 0;
        //methods
        private void ResetScreen()
        {
            //turn of timers
            btnLever.Enabled = true;
            tmrFlashLight.Enabled = false;
            tmrWindowCounter1.Enabled = false;
            tmrWindowCounter2.Enabled = false;
            tmrWindowCounter3.Enabled = false;
            //reset cash
            mydecCurrentCash = 500;
            mydecBet = 200;
            pbxWindow2.Visible = false;
            pbxWindow1.Visible = false;
            pbxWindow3.Visible = false;
            pbxFlashLight1.Visible = false;
            pbxFlashLight2.Visible = false;
            pbxFlashLight2.Visible = false;

            ShowMyCash();
            
        }
        private void ShowMyCash()
        {
            //show me the money, make sure we have it to spend
            lblBet.Text = mydecBet.ToString("C");
            lblCash.Text = mydecCurrentCash.ToString("C");
            if (mydecCurrentCash <= 0)
            {
                MessageBox.Show("You have no funds left.", "What a loser");
                ResetScreen();
            }
        }
        public frmSlotMachine()
        {
            InitializeComponent();
            ResetScreen();
        }
        private void tmrWindowCounter1_Tick(object sender, EventArgs e)
        {
            ChangePicture(tmrWindowCounter1, pbxWindow1, lblWindowCounter1);
            if (StopTimer() == true)
            {
                tmrWindowCounter1.Enabled = false;
            }

        }
        private void tmrWindowCounter2_Tick(object sender, EventArgs e)
        {
            ChangePicture(tmrWindowCounter2, pbxWindow2, lblWindowCounter2);
            if (tmrWindowCounter1.Enabled == false && StopTimer() == true)
            {                
                    tmrWindowCounter2.Enabled = false;
            }
        }
        private void tmrWindowCounter3_Tick(object sender, EventArgs e)
        {
            ChangePicture(tmrWindowCounter3, pbxWindow3, lblWindowCounter3);
            if (tmrWindowCounter2.Enabled == false && StopTimer() == true)
            {
                    tmrWindowCounter3.Enabled = false;
                    btnLever.Enabled = true;
                    btnReset.Enabled = true;
                    btnBetMore.Enabled = true;
                    btnBetLess.Enabled = true;
                    btnBetAll.Enabled = true;
                    CheckIfIWon();            
            }
                
            
        }
        private void CheckIfIWon()
        {
            //THis will check if the player has won
            if (lblWindowCounter1.Text == lblWindowCounter2.Text &&
                    lblWindowCounter2.Text == lblWindowCounter3.Text)
            {
                //BIG WINNER
                myblnFlash1 = true;
                myblnFlash2 = true;
                myblnFlash3 = true;
                mydecCurrentCash += mydecBet * 10;
            }
            else if (lblWindowCounter1.Text == lblWindowCounter2.Text)
            {
                //First Two match!!
                myblnFlash1 = true;
                myblnFlash2 = true;
                mydecCurrentCash += mydecBet * 2;
            }
            else if (lblWindowCounter2.Text == lblWindowCounter3.Text)
            {
                //First Two match!!
                myblnFlash2 = true;
                myblnFlash3= true;
                mydecCurrentCash += mydecBet * 2;
            }
            else if (lblWindowCounter1.Text == lblWindowCounter3.Text)
            {
                //First Two match!!
                myblnFlash1 = true;
                myblnFlash3 = true;
                mydecCurrentCash += mydecBet * 2;
            }
            else
            {
                //LOSER!~!!!!
            }
            ShowMyCash();
            FlashTheLights();



        }
        private void FlashTheLights()
        {
            tmrFlashLight.Enabled = myblnFlash1 || myblnFlash2 || myblnFlash3;
        }
        private void ChangePicture(Timer tmr, PictureBox window, Label lbl)
        {
            int intNextIndex = int.Parse(lbl.Text);
            intNextIndex++;
            if (intNextIndex > 6)
            {
                intNextIndex = 0;
            }
            lbl.Text = intNextIndex.ToString();
            PictureBox pbx = (PictureBox)this.Controls.Find("pbxPicture" + intNextIndex.ToString(), true)[0];
            window.BackgroundImage = pbx.BackgroundImage;

        }
        private bool StopTimer()
        {
            Random rnd = new Random();
            int intNext = rnd.Next(10);
            if (intNext == 2)
            {
                return true;
            }
            return false;
        }
        private void btnLever_Click(object sender, EventArgs e)
        {
            btnLever.Enabled = false;   //disable the button
            btnBetMore.Enabled = false;
            btnBetLess.Enabled = false;
            btnBetAll.Enabled = false;
            btnReset.Enabled = false;
            mydecCurrentCash -= mydecBet; //take away the money
            tmrWindowCounter1.Enabled = true;
            tmrWindowCounter2.Enabled = true; 
            tmrWindowCounter3.Enabled = true;
            pbxWindow2.Visible = true;
            pbxWindow1.Visible = true;
            pbxWindow3.Visible = true;

        }
        private void tmrFlashLight_Tick(object sender, EventArgs e)
        {
            if (pbxFlashLight1.BackColor == Color.DarkKhaki)
            {
                pbxFlashLight1.BackColor = Color.Gold;
            }
            else if (pbxFlashLight1.BackColor == Color.Gold)
            {
                pbxFlashLight1.BackColor = Color.Moccasin;
            }
            else
            {
                pbxFlashLight1.BackColor = Color.DarkKhaki;
            }
            pbxFlashLight2.BackColor = pbxFlashLight1.BackColor;
            pbxFlashLight3.BackColor = pbxFlashLight1.BackColor;
            if (StopTimer())
            {
                tmrFlashLight.Enabled = false;
                myblnFlash1 = false;
                myblnFlash2 = false;
                myblnFlash3 = false;
            }
            pbxFlashLight1.Visible = myblnFlash1;
            pbxFlashLight2.Visible = myblnFlash2;
            pbxFlashLight3.Visible = myblnFlash3;

        }
        private void btnReset_Click(object sender, EventArgs e)
        {
            ResetScreen();
        }
        private void btnBetMore_Click(object sender, EventArgs e)
        {
            if (mydecBet == mydecCurrentCash)
            {
                mydecBet = mydecCurrentCash;
            }
            else
            {
                mydecBet += 100;
                ShowMyCash();
            }
        }
        private void btnBetLess_Click(object sender, EventArgs e)
        {
            if (mydecBet == 0)
            {
                mydecBet = 0;
            }
            else
            {
                mydecBet -= 100;
                ShowMyCash();
            }
        }
        private void btnBetAll_Click(object sender, EventArgs e)
        {
            mydecBet = mydecCurrentCash;
            ShowMyCash();
        }
    }
}
